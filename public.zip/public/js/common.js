$(document).ready(function() {
    $('#product_table').DataTable();
});